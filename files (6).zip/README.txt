SANTANA MEDIA — IMAGES FOLDER
==============================

The site currently uses online placeholder photos so it works the moment
you open index.html. Drop your own images here when ready.

To use your own photos:

1. Place each image inside this folder (suggested subfolders below).
2. Open the relevant HTML file and replace the image URLs.

Suggested structure:
  images/
    videography/    cover.mp4, 01.jpg, 02.jpg ...
    graduation/     cover.jpg, 01.jpg, 02.jpg ...
    matric-dance/   ...
    birthdays/      ...
    events/         ...
    portraits/      ...

WHERE TO EDIT
=============

Home page (index.html):
  - Hero video — find <video> tag in the hero section, replace the
    <source src="..."> URL with: images/videography/cover.mp4
  - Category thumbnails — find each <a class="cat-card"> and update its
    <img src="..."> path.
  - Editorial rows — find each <article class="ed-row"> and update the
    <img src="..."> path.

Category pages (pages/<name>.html):
  - Hero image — find <div class="cat-hero-bg"> and update the <img src>
    (videography uses a <video> instead — replace the <source src>).
  - Gallery — find <div id="gallery" data-images='[...]'>
    The data-images attribute is a JSON array. Replace each "src"
    value with the path to your local image, for example:
      [
        {"src": "../images/portraits/01.jpg"},
        {"src": "../images/portraits/02.jpg"}
      ]
    Add or remove entries to control how many photos show. The gallery
    auto-detects aspect ratio — portraits, landscapes, ultrawides and
    tall images all render without cropping or stretching.
